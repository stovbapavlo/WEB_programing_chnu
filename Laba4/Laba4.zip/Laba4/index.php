<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Головна сторінка</title>
    <link rel="stylesheet" href="assets/css/index-styles.css">
</head>
<body>
<header>
    <div class="logo">
        <h1>Вибір спеціальності</h1>
    </div>
</header>

<div class="main-content">
    <h2>Оберіть напрям навчання та отримайте статистику по ВНЗ:</h2>

    <div class="btn-container">
        <a href="pages/form.php" class="btn">Перейти до вибору напряму</a>
    </div>
</div>

</body>
</html>
